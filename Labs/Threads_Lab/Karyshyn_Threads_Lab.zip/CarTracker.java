public class CarTracker {
    protected static int FINISHED_CARS = 0;
    protected static final int TOTAL_CARS = 3;

    public static void addFinishedCar() {
        FINISHED_CARS++;
    }
}
